#
# Cookbook Name:: test-book
# Recipe:: default
#
# Copyright 2015, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
file "/etc/init.d/test" do
  owner 'root'
  group 'root'
  mode 0755
  content ::File.open("/vagrant/test").read
  action :create
end
