file "/tmp/chef-solo-cookbook-test-default" do
  content "chef solo cookbook test default"
  owner "vagrant"
  group "vagrant"
  mode 00600
end
