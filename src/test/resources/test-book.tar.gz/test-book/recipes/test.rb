file "/tmp/chef-solo-cookbook-test" do
  content "chef solo cookbook test"
  owner "vagrant"
  group "vagrant"
  mode 00600
end